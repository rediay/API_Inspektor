﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Inspektor_API_REST.Models
{
    public partial class TipoIdentificacion1
    {
        public int IdTipoIden { get; set; }
        public string NombreIden { get; set; }
    }
}
