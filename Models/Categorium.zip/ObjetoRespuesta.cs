﻿namespace Inspektor_API_REST.Models
{
    public class ObjetoRespuesta
    {
        public int NumConsulta { get; set; }
        public int CantCoincidencias { get; set; }
        public int NumRegistro { get; set; }
        public string Prioridad { get; set; }
        public string TipoDoc { get; set; }
        public string NumDocumento { get; set; }
        public string Nombre { get; set; }
        public string NumTipoLista { get; set; }
        public string[] Lista { get; set; }
    }
}
