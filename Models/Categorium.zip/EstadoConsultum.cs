﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Inspektor_API_REST.Models
{
    public partial class EstadoConsultum
    {
        public int IdEstadoConsulta { get; set; }
        public string NombreEstado { get; set; }
    }
}
