﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Inspektor_API_REST.Models
{
    public partial class EmpresavsTipoListaPropium
    {
        public decimal IdEmpresavsTipo { get; set; }
        public int? IdEmpresa { get; set; }
        public decimal? IdTipoListaPropia { get; set; }
    }
}
