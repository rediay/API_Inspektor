﻿namespace Inspektor_API_REST.Models
{
    public class ObjetoConsulta
    {
        public int IdUsuario { get; set; }
        public int IdEmpresa { get; set; }

        public string? Nombre { get; set; }
        public string? Identificacion { get; set; }
    }
}
