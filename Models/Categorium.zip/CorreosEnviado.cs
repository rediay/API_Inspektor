﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Inspektor_API_REST.Models
{
    public partial class CorreosEnviado
    {
        public int IdCorreoEnviado { get; set; }
        public int IdEmpresa { get; set; }
        public string Asunto { get; set; }
        public string Para { get; set; }
        public string Detalle { get; set; }
        public int IdUsuario { get; set; }
        public DateTime FechaEnvio { get; set; }
        public byte? Estado { get; set; }

        public virtual Empresa IdEmpresaNavigation { get; set; }
    }
}
