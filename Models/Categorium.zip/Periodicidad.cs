﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Inspektor_API_REST.Models
{
    public partial class Periodicidad
    {
        public int IdPeriodicidad { get; set; }
        public string Periodicidad1 { get; set; }
    }
}
