﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Inspektor_API_REST.Models
{
    public partial class TablaTemporalResultado
    {
        public decimal? IdLista { get; set; }
        public decimal? Prioridad { get; set; }
        public decimal? IdConsulta { get; set; }
    }
}
