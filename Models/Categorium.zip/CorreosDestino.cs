﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Inspektor_API_REST.Models
{
    public partial class CorreosDestino
    {
        public int IdCorreosDestino { get; set; }
        public int IdEmpresa { get; set; }
        public bool Prioridad1 { get; set; }
        public string CorreosPrioridad1 { get; set; }
        public bool Prioridad2 { get; set; }
        public string CorreosPrioridad2 { get; set; }
        public bool Prioridad3 { get; set; }
        public string CorreosPrioridad3 { get; set; }
        public int IdUsuario { get; set; }
        public DateTime FechaRegitro { get; set; }
        public bool Coincidencias { get; set; }
        public string CorreosCoincidencias { get; set; }
        public DateTime? FechaCoincidencias { get; set; }
        public int? IdUsuarioCoincidencias { get; set; }
        public bool Prioridad4 { get; set; }
        public string CorreosPrioridad4 { get; set; }
        public bool SrvAdd { get; set; }
        public string CorreosPrioridadSrvAdd { get; set; }
        public DateTime? FechaMonitoreoTx { get; set; }
        public int? IdUsuarioMonitoreoTx { get; set; }

        public virtual Empresa IdEmpresaNavigation { get; set; }
    }
}
