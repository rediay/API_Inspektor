﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Inspektor_API_REST.Models
{
    public partial class TablaTemporal
    {
        public int? IdConsulta { get; set; }
        public string NombreConsulta { get; set; }
        public string IdentificacionConsulta { get; set; }
    }
}
