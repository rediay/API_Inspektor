﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Inspektor_API_REST.Models
{
    public partial class Entidade
    {
        public int IdEntidad { get; set; }
        public string NombreEntidad { get; set; }
    }
}
