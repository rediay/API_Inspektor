﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Inspektor_API_REST.Models
{
    public partial class ProcuraduriaRegistro
    {
        public decimal IdRegistro { get; set; }
        public decimal? IdConsulta { get; set; }
    }
}
